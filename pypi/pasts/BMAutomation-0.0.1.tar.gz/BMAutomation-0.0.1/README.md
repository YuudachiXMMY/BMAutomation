# BMAutomation

This is a test BenchmarkAutomation package. You can check it on [Github BMAutomation](https://github.com/YuudachiXMMY/BMAutomation).